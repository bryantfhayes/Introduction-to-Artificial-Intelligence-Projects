To run:
python project1.py <initial> <goal> <mode> <output>

Each example:
1)
python project1.py initialState1.txt goalState1.txt bfs outputfile.txt
python project1.py initialState1.txt goalState1.txt dfs outputfile.txt
python project1.py initialState1.txt goalState1.txt iddfs outputfile.txt
python project1.py initialState1.txt goalState1.txt a* outputfile.txt


2)
python project1.py initialState2.txt goalState2.txt bfs outputfile.txt
python project1.py initialState2.txt goalState2.txt dfs outputfile.txt
python project1.py initialState2.txt goalState2.txt iddfs outputfile.txt
python project1.py initialState2.txt goalState2.txt a* outputfile.txt


3)
python project1.py initialState3.txt goalState3.txt bfs outputfile.txt
python project1.py initialState3.txt goalState3.txt dfs outputfile.txt
python project1.py initialState3.txt goalState3.txt iddfs outputfile.txt
python project1.py initialState3.txt goalState3.txt a* outputfile.txt

*See report for program results.
